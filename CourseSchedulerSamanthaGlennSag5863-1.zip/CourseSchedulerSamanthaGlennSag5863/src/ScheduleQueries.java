/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class ScheduleQueries {
    private static Connection connection;
    private static ArrayList<String> faculty = new ArrayList<String>();
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement getScheduledStudentByCourse;
    private static PreparedStatement getWaitlistedStudentByCourse;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement updateScheduleEntry;
    private static ResultSet resultSet;
    
    public static void addScheduleEntry(ScheduleEntry entry)
    {
        connection = DBConnection.getConnection();
        try
        {
            addScheduleEntry = connection.prepareStatement("insert into app.schedule (semester, courseCode, studentID, status, timestamp) values (?,?,?,?,?)");
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getCourseCode());
            addScheduleEntry.setString(3, entry.getStudentID());
            addScheduleEntry.setString(4,entry.getStatus());
            addScheduleEntry.setTimestamp(5,entry.getTimestamp());
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID)
    {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> results = new ArrayList<ScheduleEntry>();
        try
        {
            getScheduleByStudent = connection.prepareStatement("select * from app.schedule where studentID = ? and semester = ?");
            getScheduleByStudent.setString(2, semester);
            getScheduleByStudent.setString(1, studentID);
            resultSet = getScheduleByStudent.executeQuery();
            
            while(resultSet.next())
            {
                results.add(new ScheduleEntry(
                        resultSet.getString("semester"),
                        resultSet.getString("courseCode"),
                        resultSet.getString("studentID"),
                        resultSet.getString("status"),
                        resultSet.getTimestamp("Timestamp")
                ));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return results;
        
    }
    
    public static int getScheduledStudentCount(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        int count = 0;
        try
        {
            getScheduledStudentCount = connection.prepareStatement("select count(studentID) from app.schedule where semester = ? and courseCode = ?");
            getScheduledStudentCount.setString(1, semester);
            getScheduledStudentCount.setString(2, courseCode);
            resultSet = getScheduledStudentCount.executeQuery();
            
            while(resultSet.next())
            {
                count = resultSet.getInt(1);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return count;
        
    }
    
    public static ArrayList<ScheduleEntry> getScheduledStudentByCourse(String semester, String courseCode){
        String status = "Scheduled";
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> results = new ArrayList<ScheduleEntry>();
        try
        {
            getScheduledStudentByCourse = connection.prepareStatement("select * from app.schedule where semester = ? and courseCode = ? and status = ?");
            getScheduledStudentByCourse.setString(1, semester);
            getScheduledStudentByCourse.setString(2, courseCode);
            getScheduledStudentByCourse.setString(3, status);
            resultSet = getScheduledStudentByCourse.executeQuery();
            
            while(resultSet.next())
            {
                results.add(new ScheduleEntry(
                        resultSet.getString("semester"),
                        resultSet.getString("courseCode"),
                        resultSet.getString("studentID"),
                        resultSet.getString("status"),
                        resultSet.getTimestamp("Timestamp")
                ));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return results;
    }
    
        public static ArrayList<ScheduleEntry> getWaitlistedStudentByCourse(String semester, String courseCode){
        String status = "Waitlisted";
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> results = new ArrayList<ScheduleEntry>();
        try
        {
            getWaitlistedStudentByCourse = connection.prepareStatement("select * from app.schedule where semester = ? and courseCode = ? and status = ? order by Timestamp");
            getWaitlistedStudentByCourse.setString(1, semester);
            getWaitlistedStudentByCourse.setString(2, courseCode);
            getWaitlistedStudentByCourse.setString(3, status);
            resultSet = getWaitlistedStudentByCourse.executeQuery();
            
            while(resultSet.next())
            {
                results.add(new ScheduleEntry(
                        resultSet.getString("semester"),
                        resultSet.getString("courseCode"),
                        resultSet.getString("studentID"),
                        resultSet.getString("status"),
                        resultSet.getTimestamp("Timestamp")
                ));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return results;
    }
    
    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode){
        connection = DBConnection.getConnection();
        try
        {
            ArrayList<ScheduleEntry> waitlistedSchedules = new ArrayList<ScheduleEntry>();
            waitlistedSchedules = getWaitlistedStudentByCourse(semester, courseCode);               
            if (waitlistedSchedules.size() != 0){
                    ScheduleEntry mostRecent = waitlistedSchedules.get(0);
                    updateScheduleEntry(semester, mostRecent);
            }

            dropStudentScheduleByCourse = connection.prepareStatement("delete from app.schedule where semester = ? and studentID = ? and courseCode = ?");
            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, studentID);
            dropStudentScheduleByCourse.setString(3, courseCode);
            dropStudentScheduleByCourse.executeUpdate();
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void dropScheduleByCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try
        {
            dropScheduleByCourse = connection.prepareStatement("delete from app.schedule where semester = ? and courseCode = ?");
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, courseCode);
            dropScheduleByCourse.executeUpdate();
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void updateScheduleEntry(String semester, ScheduleEntry entry){
        connection = DBConnection.getConnection();
        String theStatus = "Scheduled";
        try
        {
            updateScheduleEntry = connection.prepareStatement("update app.schedule set status = 'Scheduled' where studentID = ? and courseCode = ?");
            updateScheduleEntry.setString(1, entry.getStudentID());
            updateScheduleEntry.setString(2, entry.getCourseCode());
            updateScheduleEntry.executeUpdate();
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
}
